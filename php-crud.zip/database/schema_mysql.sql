CREATE TABLE IF NOT EXISTS contactos (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    nombre    VARCHAR(80)  NOT NULL,
    apellido  VARCHAR(80)  NOT NULL,
    telefono  VARCHAR(20)  NOT NULL,
    foto      VARCHAR(255) NOT NULL,
    email     VARCHAR(120) NULL,
    direccion VARCHAR(255) NULL,
    notas     TEXT NULL,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
